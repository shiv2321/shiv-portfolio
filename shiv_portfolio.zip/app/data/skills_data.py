skills = {
        "Programming": ["Python", "web2py", "Django", "FastAPI", "JavaScript"],
        "DataBase": ["MySQL", "sqlite"],
        "Networking": ["Linux (CentOS, Ubuntu)", "Logging (Syslog, logger)", "IDS/IPS (Snort)"],
        "Tools & Other":["Git & GitHub", "Docker (basic usage)", "System Design(basics)"]
        }

counter = 0